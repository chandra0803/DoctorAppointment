package com.medizine.backend;

import org.junit.jupiter.api.Test;

//@SpringBootTest
class MedizineBackendApplicationTests {

  @Test
  void contextLoads() {
  }

}
