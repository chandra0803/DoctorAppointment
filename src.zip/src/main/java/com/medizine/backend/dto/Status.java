package com.medizine.backend.dto;

public enum Status {
  ACTIVE, INACTIVE
}
