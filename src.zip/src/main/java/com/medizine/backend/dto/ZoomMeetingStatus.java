package com.medizine.backend.dto;

public enum ZoomMeetingStatus {
    COMPLETED, LIVE, UPCOMING, UNKNOWN

}