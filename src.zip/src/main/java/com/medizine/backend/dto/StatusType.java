package com.medizine.backend.dto;

public enum StatusType {
    ACTIVE, INACTIVE

}

